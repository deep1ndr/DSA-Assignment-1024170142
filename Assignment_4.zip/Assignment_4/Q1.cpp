// 1) Program for demonstrating operations on a simple Queue

#include <iostream>
#include <vector>
#include <string>

class SimpleQueue {
private:
    std::vector<std::string> queue;
    int maxSize;

public:
    // Constructor to initialize the queue with a max size
    SimpleQueue(int size) {
        maxSize = size;
    }

    // Checks if the queue is empty
    bool isEmpty() {
        return queue.empty();
    }

    // Checks if the queue is full
    bool isFull() {
        return queue.size() == maxSize;
    }

    // Adds an item to the rear of the queue
    void enqueue(const std::string& item) {
        if (isFull()) {
            std::cout << "Error: Queue is full. Cannot enqueue." << std::endl;
            return;
        }
        queue.push_back(item);
        std::cout << "Enqueued element: " << item << std::endl;
    }

    // Removes and returns the item from the front of the queue
    std::string dequeue() {
        if (isEmpty()) {
            std::cout << "Error: Queue is empty. Cannot dequeue." << std::endl;
            return ""; // Return empty string on failure
        }
        // Note: Erasing from the beginning of a vector is an O(n) operation,
        // similar to list.pop(0) in Python.
        std::string item = queue.front();
        queue.erase(queue.begin());
        std::cout << "Dequeued element: " << item << std::endl;
        return item;
    }

    // Returns the front element of the queue without removing it
    std::string peek() {
        if (isEmpty()) {
            std::cout << "Queue is empty." << std::endl;
            return "";
        }
        return queue.front();
    }

    // Displays all the elements in the queue
    void display() {
        if (isEmpty()) {
            std::cout << "Queue is empty." << std::endl;
            return;
        }
        std::cout << "Elements in the queue are: ";
        for (const auto& item : queue) {
            std::cout << item << " ";
        }
        std::cout << std::endl;
    }
};

void showMenu() {
    std::cout << "\n--- Simple Queue Operations ---" << std::endl;
    std::cout << "1. Enqueue (Add element)" << std::endl;
    std::cout << "2. Dequeue (Remove element)" << std::endl;
    std::cout << "3. Check if Empty" << std::endl;
    std::cout << "4. Check if Full" << std::endl;
    std::cout << "5. Peek (View front element)" << std::endl;
    std::cout << "6. Display Queue" << std::endl;
    std::cout << "7. Exit" << std::endl;
    std::cout << "Enter your choice (1-7): ";
}

int main() {
    int maxSize;
    std::cout << "Enter the maximum size of the queue: ";
    std::cin >> maxSize;

    if (maxSize <= 0) {
        std::cout << "Size must be a positive integer." << std::endl;
        return 1;
    }

    SimpleQueue q(maxSize);
    int choice;
    std::string item;

    while (true) {
        showMenu();
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter the element to enqueue: ";
                std::cin >> item;
                q.enqueue(item);
                break;
            case 2:
                q.dequeue();
                break;
            case 3:
                if (q.isEmpty()) {
                    std::cout << "The queue is empty." << std::endl;
                } else {
                    std::cout << "The queue is not empty." << std::endl;
                }
                break;
            case 4:
                if (q.isFull()) {
                    std::cout << "The queue is full." << std::endl;
                } else {
                    std::cout << "The queue is not full." << std::endl;
                }
                break;
            case 5:
                item = q.peek();
                if (!item.empty()) {
                    std::cout << "The front element is: " << item << std::endl;
                }
                break;
            case 6:
                q.display();
                break;
            case 7:
                std::cout << "Exiting program." << std::endl;
                return 0;
            default:
                std::cout << "Invalid choice. Please enter a number between 1 and 7." << std::endl;
        }
    }

    return 0;
}
