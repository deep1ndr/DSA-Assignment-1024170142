// 3) Write a program to interleave the first half of the queue with the second half.
// Sample I/P: 4 7 11 20 5 9
// Sample O/P: 4 20 7 5 11 9

#include <iostream>
#include <queue>

// Function to display the elements of a queue
void displayQueue(std::queue<int> q) {
    while (!q.empty()) {
        std::cout << q.front() << " ";
        q.pop();
    }
    std::cout << std::endl;
}

// Function to interleave the queue
void interleaveQueue(std::queue<int>& q) {
    if (q.size() % 2 != 0) {
        std::cout << "Cannot interleave a queue with an odd number of elements." << std::endl;
        return;
    }

    // 1. Dequeue the first half and push into a temporary queue
    std::queue<int> temp;
    int halfSize = q.size() / 2;
    for (int i = 0; i < halfSize; ++i) {
        temp.push(q.front());
        q.pop();
    }

    // 2. Interleave the elements
    while (!temp.empty()) {
        // Add from the first half
        q.push(temp.front());
        temp.pop();

        // Move element from the second half to the back
        q.push(q.front());
        q.pop();
    }
}

int main() {
    std::queue<int> q;
    q.push(4);
    q.push(7);
    q.push(11);
    q.push(20);
    q.push(5);
    q.push(9);

    std::cout << "Original Queue: ";
    displayQueue(q);

    interleaveQueue(q);

    std::cout << "Interleaved Queue: ";
    displayQueue(q);

    return 0;
}
