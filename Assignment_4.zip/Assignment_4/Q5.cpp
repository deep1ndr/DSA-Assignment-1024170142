// 5) Write a program to implement a stack using (a) Two queues and (b) One Queue.

#include <iostream>
#include <queue>

// (a) Implementation of a Stack using two queues
class StackWithTwoQueues {
private:
    std::queue<int> q1;
    std::queue<int> q2;

public:
    // Push operation is made costly
    void push(int x) {
        // 1. Add new element to the empty queue q2
        q2.push(x);

        // 2. Move all elements from q1 to q2
        while (!q1.empty()) {
            q2.push(q1.front());
            q1.pop();
        }

        // 3. Swap the names of q1 and q2
        std::swap(q1, q2);
    }

    // Pop operation is O(1)
    void pop() {
        if (q1.empty()) {
            std::cout << "Stack is empty" << std::endl;
            return;
        }
        q1.pop();
    }

    int top() {
        if (q1.empty()) {
            return -1; // Or throw an exception
        }
        return q1.front();
    }

    bool empty() {
        return q1.empty();
    }
};

// (b) Implementation of a Stack using one queue
class StackWithOneQueue {
private:
    std::queue<int> q;

public:
    void push(int x) {
        // 1. Get current size of queue
        int s = q.size();

        // 2. Add the new element
        q.push(x);

        // 3. Rotate the queue to make the new element the front
        for (int i = 0; i < s; i++) {
            q.push(q.front());
            q.pop();
        }
    }

    void pop() {
        if (q.empty()) {
            std::cout << "Stack is empty" << std::endl;
            return;
        }
        q.pop();
    }

    int top() {
        if (q.empty()) {
            return -1;
        }
        return q.front();
    }

    bool empty() {
        return q.empty();
    }
};


int main() {
    std::cout << "--- Stack using Two Queues ---" << std::endl;
    StackWithTwoQueues s1;
    s1.push(1);
    s1.push(2);
    s1.push(3);

    std::cout << "Top element is: " << s1.top() << std::endl; // Should be 3
    s1.pop();
    std::cout << "Top element is: " << s1.top() << std::endl; // Should be 2
    s1.pop();
    std::cout << "Top element is: " << s1.top() << std::endl; // Should be 1

    std::cout << "\n--- Stack using One Queue ---" << std::endl;
    StackWithOneQueue s2;
    s2.push(10);
    s2.push(20);
    s2.push(30);

    std::cout << "Top element is: " << s2.top() << std::endl; // Should be 30
    s2.pop();
    std::cout << "Top element is: " << s2.top() << std::endl; // Should be 20
    s2.pop();
    std::cout << "Top element is: " << s2.top() << std::endl; // Should be 10

    return 0;
}
