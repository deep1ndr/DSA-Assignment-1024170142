// 2) Program for demonstrating operations on a Circular Queue

#include <iostream>
#include <string>
#include <vector>

class CircularQueue {
private:
    std::vector<std::string> queue;
    int size;
    int front;
    int rear;

public:
    // Constructor
    CircularQueue(int s) {
        size = s;
        front = -1;
        rear = -1;
        queue.resize(s);
    }

    // Checks if the queue is full
    bool isFull() {
        return (rear + 1) % size == front;
    }

    // Checks if the queue is empty
    bool isEmpty() {
        return front == -1;
    }

    // Adds an item to the rear of the queue
    void enqueue(const std::string& item) {
        if (isFull()) {
            std::cout << "Error: Queue is full. Cannot enqueue." << std::endl;
            return;
        }
        if (isEmpty()) {
            front = 0;
        }
        rear = (rear + 1) % size;
        queue[rear] = item;
        std::cout << "Enqueued element: " << item << std::endl;
    }

    // Removes an item from the front of the queue
    std::string dequeue() {
        if (isEmpty()) {
            std::cout << "Error: Queue is empty. Cannot dequeue." << std::endl;
            return "";
        }
        std::string item = queue[front];
        if (front == rear) {
            // Reset queue if it was the last element
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % size;
        }
        std::cout << "Dequeued element: " << item << std::endl;
        return item;
    }

    // Returns the front element without removing it
    std::string peek() {
        if (isEmpty()) {
            std::cout << "Queue is empty." << std::endl;
            return "";
        }
        return queue[front];
    }

    // Displays the elements of the circular queue
    void display() {
        if (isEmpty()) {
            std::cout << "Queue is empty." << std::endl;
            return;
        }
        std::cout << "Elements in the circular queue are: ";
        int i = front;
        while (true) {
            std::cout << queue[i] << " ";
            if (i == rear) {
                break;
            }
            i = (i + 1) % size;
        }
        std::cout << std::endl;
    }
};


void showMenu() {
    std::cout << "\n--- Circular Queue Operations ---" << std::endl;
    std::cout << "1. Enqueue (Add element)" << std::endl;
    std::cout << "2. Dequeue (Remove element)" << std::endl;
    std::cout << "3. Check if Empty" << std::endl;
    std::cout << "4. Check if Full" << std::endl;
    std::cout << "5. Peek (View front element)" << std::endl;
    std::cout << "6. Display Queue" << std::endl;
    std::cout << "7. Exit" << std::endl;
    std::cout << "Enter your choice (1-7): ";
}


int main() {
    int maxSize;
    std::cout << "Enter the maximum size of the circular queue: ";
    std::cin >> maxSize;
     if (maxSize <= 0) {
        std::cout << "Size must be a positive integer." << std::endl;
        return 1;
    }

    CircularQueue cq(maxSize);
    int choice;
    std::string item;

    while (true) {
        showMenu();
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter the element to enqueue: ";
                std::cin >> item;
                cq.enqueue(item);
                break;
            case 2:
                cq.dequeue();
                break;
            case 3:
                if (cq.isEmpty()) {
                    std::cout << "The queue is empty." << std::endl;
                } else {
                    std::cout << "The queue is not empty." << std::endl;
                }
                break;
            case 4:
                if (cq.isFull()) {
                    std::cout << "The queue is full." << std::endl;
                } else {
                    std::cout << "The queue is not full." << std::endl;
                }
                break;
            case 5:
                item = cq.peek();
                if (!item.empty()) {
                    std::cout << "The front element is: " << item << std::endl;
                }
                break;
            case 6:
                cq.display();
                break;
            case 7:
                std::cout << "Exiting program." << std::endl;
                return 0;
            default:
                std::cout << "Invalid choice. Please enter a number between 1 and 7." << std::endl;
        }
    }

    return 0;
}
