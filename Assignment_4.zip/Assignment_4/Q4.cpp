// 4) Write a program to find the first non-repeating character in a string using a Queue.
// Sample I/P: a a b c
// Sample O/P: a -1 b b
// This means for "a", output is 'a'. For "aa", output is '-1'. For "aab", output is 'b', etc.

#include <iostream>
#include <string>
#include <queue>
#include <map>

void findFirstNonRepeating(const std::string& str) {
    std::map<char, int> freq;
    std::queue<char> q;

    std::cout << "Input Stream: " << str << std::endl;
    std::cout << "Output: ";

    for (char ch : str) {
        // Increment frequency of the character
        freq[ch]++;
        
        // If it's the first time, add it to the queue
        if (freq[ch] == 1) {
            q.push(ch);
        }

        // Remove repeating characters from the front of the queue
        while (!q.empty() && freq[q.front()] > 1) {
            q.pop();
        }

        // Print the first non-repeating character
        if (q.empty()) {
            std::cout << "-1 ";
        } else {
            std::cout << q.front() << " ";
        }
    }
    std::cout << std::endl;
}

int main() {
    std::string inputStream = "aabc";
    findFirstNonRepeating(inputStream);

    std::string inputStream2 = "zzxyy";
    findFirstNonRepeating(inputStream2);
    
    return 0;
}
