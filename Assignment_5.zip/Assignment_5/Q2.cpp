#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

void push(struct Node** head_ref, int new_data) {
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
    if (new_node == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
    new_node->data = new_data;
    new_node->next = (*head_ref);
    (*head_ref) = new_node;
}

void printList(struct Node* node) {
    while (node != NULL) {
        printf("%d", node->data);
        if (node->next != NULL) {
            printf("->");
        }
        node = node->next;
    }
    printf("\n");
}

int countOccurrences(struct Node* head, int key) {
    struct Node* current = head;
    int count = 0;
    while (current != NULL) {
        if (current->data == key) {
            count++;
        }
        current = current->next;
    }
    return count;
}

void deleteAllOccurrences(struct Node** head_ref, int key) {
    struct Node* temp = *head_ref;
    struct Node* prev = NULL;

    
    while (temp != NULL && temp->data == key) {
        *head_ref = temp->next; 
        free(temp);             
        temp = *head_ref;       
    }

    prev = NULL;
    temp = *head_ref;

    while (temp != NULL) {
        if (temp->data == key) {
            if (prev != NULL) {
                prev->next = temp->next;
            }
            struct Node* to_delete = temp;
            temp = temp->next;
            free(to_delete);
        } else {
            prev = temp;
            temp = temp->next;
        }
    }
}

int main() {
    struct Node* head = NULL;

    push(&head, 1);
    push(&head, 3);
    push(&head, 1);
    push(&head, 2);
    push(&head, 1);
    push(&head, 2);
    push(&head, 1);

    int key = 1;

    printf("Input Linked List: ");
    printList(head);

    int count = countOccurrences(head, key);
    printf("Count: %d\n", count);

    deleteAllOccurrences(&head, key);

    printf("Updated Linked List: ");
    printList(head);
    
    struct Node* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}