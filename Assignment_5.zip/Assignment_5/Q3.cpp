#include <iostream>

struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

void push(Node** head_ref, int new_data) {
    Node* new_node = new Node(new_data);
    new_node->next = (*head_ref);
    (*head_ref) = new_node;
}

void printList(Node* node) {
    while (node != nullptr) {
        std::cout << node->data;
        if (node->next != nullptr) {
            std::cout << "->";
        }
        node = node->next;
    }
    std::cout << std::endl;
}

int findMiddle(Node* head) {
    if (head == nullptr) {
        return -1; 
    }

    Node* slow = head;
    Node* fast = head;

    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }

    return slow->data;
}

int main() {
    Node* head = nullptr;

    push(&head, 5);
    push(&head, 4);
    push(&head, 3);
    push(&head, 2);
    push(&head, 1);

    std::cout << "Input: ";
    printList(head);

    int middleElement = findMiddle(head);

    std::cout << "Output: " << middleElement << std::endl;

    Node* current = head;
    Node* nextNode = nullptr;
    while (current != nullptr) {
        nextNode = current->next;
        delete current;
        current = nextNode;
    }

    return 0;
}