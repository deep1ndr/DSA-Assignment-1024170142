#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct Node* head = NULL;

void insertAtBeginning() {
    int value;
    printf("Enter value to insert: ");
    scanf("%d", &value);

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
    
    newNode->data = value;
    newNode->next = head;
    head = newNode;
    printf("%d inserted at the beginning.\n", value);
}

void insertAtEnd() {
    int value;
    printf("Enter value to insert: ");
    scanf("%d", &value);

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
    
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
    } else {
        struct Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
    printf("%d inserted at the end.\n", value);
}

void insertAfterNode() {
    int newValue, targetValue;
    printf("Enter value of the new node: ");
    scanf("%d", &newValue);
    printf("Enter value of the node to insert AFTER: ");
    scanf("%d", &targetValue);

    struct Node* temp = head;
    while (temp != NULL && temp->data != targetValue) {
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Node with value %d not found.\n", targetValue);
        return;
    }

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }

    newNode->data = newValue;
    newNode->next = temp->next;
    temp->next = newNode;
    printf("%d inserted after %d.\n", newValue, targetValue);
}

void insertBeforeNode() {
    int newValue, targetValue;
    printf("Enter value of the new node: ");
    scanf("%d", &newValue);
    printf("Enter value of the node to insert BEFORE: ");
    scanf("%d", &targetValue);

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
    newNode->data = newValue;

    if (head == NULL) {
        printf("List is empty. Cannot insert before.\n");
        free(newNode);
        return;
    }

    if (head->data == targetValue) {
        newNode->next = head;
        head = newNode;
        printf("%d inserted before %d.\n", newValue, targetValue);
        return;
    }

    struct Node* temp = head;
    struct Node* prev = NULL;
    while (temp != NULL && temp->data != targetValue) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Node with value %d not found.\n", targetValue);
        free(newNode);
        return;
    }

    newNode->next = temp;
    prev->next = newNode;
    printf("%d inserted before %d.\n", newValue, targetValue);
}

void insertInBetween() {
    int choice;
    printf("1. Insert Before a Node\n");
    printf("2. Insert After a Node\n");
    printf("Enter choice: ");
    scanf("%d", &choice);

    if (choice == 1) {
        insertBeforeNode();
    } else if (choice == 2) {
        insertAfterNode();
    } else {
        printf("Invalid choice.\n");
    }
}

void deleteFromBeginning() {
    if (head == NULL) {
        printf("List is empty. Nothing to delete.\n");
        return;
    }

    struct Node* temp = head;
    head = head->next;
    printf("Deleted node: %d\n", temp->data);
    free(temp);
}

void deleteFromEnd() {
    if (head == NULL) {
        printf("List is empty. Nothing to delete.\n");
        return;
    }

    if (head->next == NULL) {
        printf("Deleted node: %d\n", head->data);
        free(head);
        head = NULL;
        return;
    }

    struct Node* temp = head;
    struct Node* prev = NULL;
    while (temp->next != NULL) {
        prev = temp;
        temp = temp->next;
    }

    prev->next = NULL;
    printf("Deleted node: %d\n", temp->data);
    free(temp);
}

void deleteSpecificNode() {
    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }

    int key;
    printf("Enter value of the node to delete: ");
    scanf("%d", &key);

    struct Node* temp = head;
    struct Node* prev = NULL;

    if (temp != NULL && temp->data == key) {
        head = temp->next;
        printf("Deleted node: %d\n", temp->data);
        free(temp);
        return;
    }

    while (temp != NULL && temp->data != key) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Node with value %d not found.\n", key);
        return;
    }

    prev->next = temp->next;
    printf("Deleted node: %d\n", temp->data);
    free(temp);
}

void searchNode() {
    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }

    int key;
    printf("Enter value to search: ");
    scanf("%d", &key);

    struct Node* temp = head;
    int position = 1;
    while (temp != NULL) {
        if (temp->data == key) {
            printf("Node %d found at position %d.\n", key, position);
            return;
        }
        temp = temp->next;
        position++;
    }

    printf("Node %d not found in the list.\n", key);
}

void displayList() {
    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }

    struct Node* temp = head;
    printf("List: HEAD -> ");
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

int main() {
    int choice;
    
    while (1) {
        printf("\n--- Singly Linked List Menu ---\n");
        printf("1. (a) Insert at the beginning\n");
        printf("2. (b) Insert at the end\n");
        printf("3. (c) Insert in between (before/after)\n");
        printf("4. (d) Delete from the beginning\n");
        printf("5. (e) Delete from the end\n");
        printf("6. (f) Delete a specific node\n");
        printf("7. (g) Search for a node\n");
        printf("8. (h) Display all node values\n");
        printf("0. Exit\n");
        printf("----------------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                insertAtBeginning();
                break;
            case 2:
                insertAtEnd();
                break;
            case 3:
                insertInBetween();
                break;
            case 4:
                deleteFromBeginning();
                break;
            case 5:
                deleteFromEnd();
                break;
            case 6:
                deleteSpecificNode();
                break;
            case 7:
                searchNode();
                break;
            case 8:
                displayList();
                break;
            case 0:
                printf("Exiting program.\n");
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}