// 3. Write a program that checks if an expression has balanced parentheses.

#include <iostream>
#include <string>
#include <stack>

// Function to check if parentheses are balanced
bool areParenthesesBalanced(std::string expr) {
    std::stack<char> s;
    char ch;

    // Traversing the Expression
    for (int i = 0; i < expr.length(); i++) {
        if (expr[i] == '(' || expr[i] == '[' || expr[i] == '{') {
            // Push the element in the stack
            s.push(expr[i]);
            continue;
        }

        // If current character is not opening bracket, then it must be closing.
        // So stack cannot be empty at this point.
        if (s.empty()) {
            return false;
        }

        switch (expr[i]) {
        case ')':
            ch = s.top();
            s.pop();
            if (ch == '{' || ch == '[')
                return false;
            break;

        case '}':
            ch = s.top();
            s.pop();
            if (ch == '(' || ch == '[')
                return false;
            break;

        case ']':
            ch = s.top();
            s.pop();
            if (ch == '(' || ch == '{')
                return false;
            break;
        }
    }

    // Check Empty Stack
    return (s.empty());
}

int main() {
    std::string expr1 = "{()}[]";
    std::string expr2 = "{(])}";
    std::string expr3 = "()";

    if (areParenthesesBalanced(expr1))
        std::cout << "Expression '" << expr1 << "' is Balanced" << std::endl;
    else
        std::cout << "Expression '" << expr1 << "' is Not Balanced" << std::endl;

    if (areParenthesesBalanced(expr2))
        std::cout << "Expression '" << expr2 << "' is Balanced" << std::endl;
    else
        std::cout << "Expression '" << expr2 << "' is Not Balanced" << std::endl;
        
    if (areParenthesesBalanced(expr3))
        std::cout << "Expression '" << expr3 << "' is Balanced" << std::endl;
    else
        std::cout << "Expression '" << expr3 << "' is Not Balanced" << std::endl;

    return 0;
}
