// 5. Write a program for the evaluation of a Postfix expression.
// This example assumes single-digit numbers.

#include <iostream>
#include <stack>
#include <string>
#include <cmath> // For pow function if using '^'

// Function to evaluate Postfix expression
int evaluatePostfix(std::string exp) {
    std::stack<int> st;

    // Scan all characters one by one
    for (int i = 0; i < exp.length(); ++i) {
        char c = exp[i];

        // If the scanned character is an operand (a number),
        // push it to the stack.
        if (isdigit(c)) {
            st.push(c - '0'); // Convert char to int
        }
        // If the scanned character is an operator, pop two
        // elements from stack and apply the operator
        else {
            int val1 = st.top();
            st.pop();
            int val2 = st.top();
            st.pop();
            switch (c) {
            case '+':
                st.push(val2 + val1);
                break;
            case '-':
                st.push(val2 - val1);
                break;
            case '*':
                st.push(val2 * val1);
                break;
            case '/':
                st.push(val2 / val1);
                break;
            case '^':
                st.push(pow(val2, val1));
                break;
            }
        }
    }
    return st.top();
}

int main() {
    std::string exp = "231*+9-";
    std::cout << "Postfix expression: " << exp << std::endl;
    std::cout << "Result: " << evaluatePostfix(exp) << std::endl; // Should be -4
    
    std::string exp2 = "82/3+5*";
    std::cout << "\nPostfix expression: " << exp2 << std::endl;
    std::cout << "Result: " << evaluatePostfix(exp2) << std::endl; // Should be 35

    return 0;
}
