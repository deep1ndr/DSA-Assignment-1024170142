// 4. Write a program to convert an Infix expression into a Postfix expression.

#include <iostream>
#include <stack>
#include <string>
#include <algorithm>

// Function to return precedence of operators
int getPrecedence(char c) {
    if (c == '^')
        return 3;
    else if (c == '*' || c == '/')
        return 2;
    else if (c == '+' || c == '-')
        return 1;
    else
        return -1; // for '('
}

// Function to convert infix expression to postfix expression
std::string infixToPostfix(std::string s) {
    std::stack<char> st;
    std::string result;

    for (int i = 0; i < s.length(); i++) {
        char c = s[i];

        // If the scanned character is an operand, add it to output string.
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
            result += c;

        // If the scanned character is an '(', push it to the stack.
        else if (c == '(')
            st.push('(');

        // If the scanned character is an ')', pop and add to output string from the stack
        // until an '(' is encountered.
        else if (c == ')') {
            while (!st.empty() && st.top() != '(') {
                result += st.top();
                st.pop();
            }
            if (!st.empty()) {
                st.pop(); // Pop '('
            }
        }

        // If an operator is scanned
        else {
            while (!st.empty() && getPrecedence(s[i]) <= getPrecedence(st.top())) {
                result += st.top();
                st.pop();
            }
            st.push(c);
        }
    }

    // Pop all the remaining elements from the stack
    while (!st.empty()) {
        result += st.top();
        st.pop();
    }

    return result;
}

int main() {
    std::string exp = "a+b*(c^d-e)^(f+g*h)-i";
    std::cout << "Infix expression: " << exp << std::endl;
    std::cout << "Postfix expression: " << infixToPostfix(exp) << std::endl;
    return 0;
}
