// 1. Develop a menu-driven program demonstrating the following operations on a Stack using an array:
// (i) push(), (ii) pop(), (iii) isEmpty(), (iv) isFull(), (v) display(), and (vi) peek().

#include <iostream>
#include <string>
#include <vector>

#define MAX_SIZE 100 // Pre-defined max size for the stack array

class Stack {
private:
    int arr[MAX_SIZE];
    int top;

public:
    // Constructor
    Stack() {
        top = -1; // Initialize stack to be empty
    }

    // (i) push() operation
    void push(int value) {
        if (isFull()) {
            std::cout << "Stack Overflow! Cannot push element." << std::endl;
            return;
        }
        arr[++top] = value;
        std::cout << value << " pushed to stack." << std::endl;
    }

    // (ii) pop() operation
    int pop() {
        if (isEmpty()) {
            std::cout << "Stack Underflow! Cannot pop element." << std::endl;
            return -1; // Return a sentinel value for error
        }
        int value = arr[top--];
        return value;
    }

    // (iii) isEmpty() check
    bool isEmpty() {
        return top == -1;
    }

    // (iv) isFull() check
    bool isFull() {
        return top == MAX_SIZE - 1;
    }

    // (v) display() all elements
    void display() {
        if (isEmpty()) {
            std::cout << "Stack is empty." << std::endl;
            return;
        }
        std::cout << "Elements in stack are: ";
        for (int i = top; i >= 0; i--) {
            std::cout << arr[i] << " ";
        }
        std::cout << std::endl;
    }

    // (vi) peek() operation
    int peek() {
        if (isEmpty()) {
            std::cout << "Stack is empty." << std::endl;
            return -1; // Return a sentinel value for error
        }
        return arr[top];
    }
};

void showMenu() {
    std::cout << "\n--- Stack Operations Menu ---" << std::endl;
    std::cout << "1. Push" << std::endl;
    std::cout << "2. Pop" << std::endl;
    std::cout << "3. Check if Empty" << std::endl;
    std::cout << "4. Check if Full" << std::endl;
    std::cout << "5. Peek (View Top Element)" << std::endl;
    std::cout << "6. Display Stack" << std::endl;
    std::cout << "7. Exit" << std::endl;
    std::cout << "Enter your choice: ";
}

int main() {
    Stack s;
    int choice, value;

    while (true) {
        showMenu();
        std::cin >> choice;
        switch (choice) {
            case 1:
                std::cout << "Enter a value to push: ";
                std::cin >> value;
                s.push(value);
                break;
            case 2:
                value = s.pop();
                if (value != -1) {
                    std::cout << "Popped value is: " << value << std::endl;
                }
                break;
            case 3:
                if (s.isEmpty()) {
                    std::cout << "Stack is empty." << std::endl;
                } else {
                    std::cout << "Stack is not empty." << std::endl;
                }
                break;
            case 4:
                if (s.isFull()) {
                    std::cout << "Stack is full." << std::endl;
                } else {
                    std::cout << "Stack is not full." << std::endl;
                }
                break;
            case 5:
                value = s.peek();
                if (value != -1) {
                    std::cout << "Top element is: " << value << std::endl;
                }
                break;
            case 6:
                s.display();
                break;
            case 7:
                std::cout << "Exiting program." << std::endl;
                return 0;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    }
    return 0;
}
