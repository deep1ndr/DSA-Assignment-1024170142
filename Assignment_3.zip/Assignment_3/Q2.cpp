// 2. Given a string, reverse it using STACK. 
// For example “DataStructure” should be output as “erutcurtSataD.”

#include <iostream>
#include <string>
#include <stack>

// Function to reverse a string using a stack
void reverseString(std::string& str) {
    std::stack<char> s;

    // Push all characters of the string into the stack
    for (char ch : str) {
        s.push(ch);
    }

    // Pop all characters from the stack and put them back to the string
    for (int i = 0; i < str.length(); i++) {
        str[i] = s.top();
        s.pop();
    }
}

int main() {
    std::string myString = "DataStructure";
    
    std::cout << "Original string: " << myString << std::endl;

    reverseString(myString);

    std::cout << "Reversed string: " << myString << std::endl;

    return 0;
}
