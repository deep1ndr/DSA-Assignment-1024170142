#include <iostream>

using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = nullptr;
    }
};

class LinkedList {
public:
    Node* head;
    Node* tail;

    LinkedList() {
        head = nullptr;
        tail = nullptr;
    }

    ~LinkedList() {
    }

    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (head == nullptr) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    void createLoop() {
        if (tail != nullptr) {
            tail->next = head; 
        }
    }

    bool isCircular() {
        if (head == nullptr) {
            return false;
        }

        Node* slow = head;
        Node* fast = head;

        while (fast != nullptr && fast->next != nullptr) {
            slow = slow->next;
            fast = fast->next->next;

            if (slow == fast) {
                return true;
            }
        }

        return false;
    }
};

int main() {
    LinkedList list1;
    list1.insertAtEnd(1);
    list1.insertAtEnd(2);
    list1.insertAtEnd(3);
    list1.insertAtEnd(4);

    cout << "List 1 (1->2->3->4->NULL):" << endl;
    if (list1.isCircular()) {
        cout << "List is circular." << endl;
    } else {
        cout << "List is not circular." << endl;
    }

    cout << "\n";

    LinkedList list2;
    list2.insertAtEnd(10);
    list2.insertAtEnd(20);
    list2.insertAtEnd(30);
    list2.insertAtEnd(40);
    list2.createLoop(); 

    cout << "List 2 (10->20->30->40->...->10):" << endl;
    if (list2.isCircular()) {
        cout << "List is circular." << endl;
    } else {
        cout << "List is not circular." << endl;
    }
    
    cout << "\n";

    LinkedList list3;
    list3.insertAtEnd(5);
    
    cout << "List 3 (5->NULL):" << endl;
    if (list3.isCircular()) {
        cout << "List is circular." << endl;
    } else {
        cout << "List is not circular." << endl;
    }
    
    cout << "\n";

    LinkedList list4;
    
    cout << "List 4 (Empty):" << endl;
    if (list4.isCircular()) {
        cout << "List is circular." << endl;
    } else {
        cout << "List is not circular." << endl;
    }

    return 0;
}