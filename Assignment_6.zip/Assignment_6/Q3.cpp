#include <iostream>

using namespace std;

struct DllNode {
    int data;
    DllNode* prev;
    DllNode* next;

    DllNode(int val) {
        data = val;
        prev = nullptr;
        next = nullptr;
    }
};

class DoublyLinkedList {
private:
    DllNode* head;
    DllNode* tail;

public:
    DoublyLinkedList() {
        head = nullptr;
        tail = nullptr;
    }

    ~DoublyLinkedList() {
        DllNode* current = head;
        while (current != nullptr) {
            DllNode* next = current->next;
            delete current;
            current = next;
        }
    }

    void insertAtEnd(int val) {
        DllNode* newNode = new DllNode(val);
        if (tail == nullptr) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    int getSize() {
        int count = 0;
        DllNode* temp = head;
        while (temp != nullptr) {
            count++;
            temp = temp->next;
        }
        return count;
    }
};

struct CllNode {
    int data;
    CllNode* next;

    CllNode(int val) {
        data = val;
        next = nullptr;
    }
};

class CircularLinkedList {
private:
    CllNode* last;

public:
    CircularLinkedList() {
        last = nullptr;
    }

    ~CircularLinkedList() {
        if (last == nullptr) return;
        CllNode* current = last->next;
        while (current != last) {
            CllNode* next = current->next;
            delete current;
            current = next;
        }
        delete last;
    }

    void insertAtEnd(int val) {
        CllNode* newNode = new CllNode(val);
        if (last == nullptr) {
            last = newNode;
            newNode->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
            last = newNode;
        }
    }

    int getSize() {
        if (last == nullptr) {
            return 0;
        }

        int count = 0;
        CllNode* temp = last->next;
        do {
            count++;
            temp = temp->next;
        } while (temp != last->next);
        
        return count;
    }
};

int main() {
    DoublyLinkedList dll;
    dll.insertAtEnd(10);
    dll.insertAtEnd(20);
    dll.insertAtEnd(30);

    cout << "--- Doubly Linked List ---" << endl;
    cout << "Size: " << dll.getSize() << endl;

    CircularLinkedList cll;
    cll.insertAtEnd(100);
    cll.insertAtEnd(200);
    cll.insertAtEnd(300);
    cll.insertAtEnd(400);

    cout << "\n--- Circular Linked List ---" << endl;
    cout << "Size: " << cll.getSize() << endl;

    return 0;
}