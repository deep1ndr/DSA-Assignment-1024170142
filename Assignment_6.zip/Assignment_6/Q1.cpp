#include <iostream>

using namespace std;

struct DllNode {
    int data;
    DllNode* prev;
    DllNode* next;

    DllNode(int val) {
        data = val;
        prev = nullptr;
        next = nullptr;
    }
};

class DoublyLinkedList {
private:
    DllNode* head;
    DllNode* tail;

public:
    DoublyLinkedList() {
        head = nullptr;
        tail = nullptr;
    }

    ~DoublyLinkedList() {
        DllNode* current = head;
        while (current != nullptr) {
            DllNode* next = current->next;
            delete current;
            current = next;
        }
    }

    void insertAtBeginning(int val) {
        DllNode* newNode = new DllNode(val);
        if (head == nullptr) {
            head = tail = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        cout << val << " inserted at the beginning." << endl;
    }

    void insertAtEnd(int val) {
        DllNode* newNode = new DllNode(val);
        if (tail == nullptr) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        cout << val << " inserted at the end." << endl;
    }

    void insertAfterNode(int key, int val) {
        DllNode* temp = head;
        while (temp != nullptr && temp->data != key) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Node with key " << key << " not found." << endl;
            return;
        }

        DllNode* newNode = new DllNode(val);
        newNode->next = temp->next;
        newNode->prev = temp;
        temp->next = newNode;

        if (newNode->next != nullptr) {
            newNode->next->prev = newNode;
        } else {
            tail = newNode;
        }
        cout << val << " inserted after " << key << "." << endl;
    }

    void insertBeforeNode(int key, int val) {
        DllNode* temp = head;
        while (temp != nullptr && temp->data != key) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Node with key " << key << " not found." << endl;
            return;
        }

        DllNode* newNode = new DllNode(val);
        newNode->prev = temp->prev;
        newNode->next = temp;
        temp->prev = newNode;

        if (newNode->prev != nullptr) {
            newNode->prev->next = newNode;
        } else {
            head = newNode;
        }
        cout << val << " inserted before " << key << "." << endl;
    }

    void deleteNode(int val) {
        DllNode* temp = head;
        while (temp != nullptr && temp->data != val) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Node with value " << val << " not found." << endl;
            return;
        }

        if (temp == head) {
            head = temp->next;
        }
        if (temp == tail) {
            tail = temp->prev;
        }

        if (temp->prev != nullptr) {
            temp->prev->next = temp->next;
        }
        if (temp->next != nullptr) {
            temp->next->prev = temp->prev;
        }

        delete temp;
        cout << "Node with value " << val << " deleted." << endl;
    }

    void searchNode(int val) {
        DllNode* temp = head;
        int pos = 1;
        while (temp != nullptr) {
            if (temp->data == val) {
                cout << "Node with value " << val << " found at position " << pos << "." << endl;
                return;
            }
            temp = temp->next;
            pos++;
        }
        cout << "Node with value " << val << " not found." << endl;
    }

    void display() {
        if (head == nullptr) {
            cout << "List is empty." << endl;
            return;
        }
        DllNode* temp = head;
        cout << "List (forward): NULL <-> ";
        while (temp != nullptr) {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
};

struct CllNode {
    int data;
    CllNode* next;

    CllNode(int val) {
        data = val;
        next = nullptr;
    }
};

class CircularLinkedList {
private:
    CllNode* last;

public:
    CircularLinkedList() {
        last = nullptr;
    }

    ~CircularLinkedList() {
        if (last == nullptr) return;
        CllNode* current = last->next;
        while (current != last) {
            CllNode* next = current->next;
            delete current;
            current = next;
        }
        delete last;
    }

    void insertAtBeginning(int val) {
        CllNode* newNode = new CllNode(val);
        if (last == nullptr) {
            last = newNode;
            newNode->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
        }
        cout << val << " inserted at the beginning." << endl;
    }

    void insertAtEnd(int val) {
        CllNode* newNode = new CllNode(val);
        if (last == nullptr) {
            last = newNode;
            newNode->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
            last = newNode;
        }
        cout << val << " inserted at the end." << endl;
    }

    void insertAfterNode(int key, int val) {
        if (last == nullptr) {
            cout << "List is empty. Cannot insert." << endl;
            return;
        }

        CllNode* temp = last->next;
        do {
            if (temp->data == key) {
                CllNode* newNode = new CllNode(val);
                newNode->next = temp->next;
                temp->next = newNode;
                if (temp == last) {
                    last = newNode;
                }
                cout << val << " inserted after " << key << "." << endl;
                return;
            }
            temp = temp->next;
        } while (temp != last->next);

        cout << "Node with key " << key << " not found." << endl;
    }

    void insertBeforeNode(int key, int val) {
        if (last == nullptr) {
            cout << "List is empty. Cannot insert." << endl;
            return;
        }

        CllNode* curr = last->next;
        CllNode* prev = last;

        do {
            if (curr->data == key) {
                CllNode* newNode = new CllNode(val);
                newNode->next = curr;
                prev->next = newNode;
                if (curr == last->next) {
                }
                cout << val << " inserted before " << key << "." << endl;
                return;
            }
            prev = curr;
            curr = curr->next;
        } while (curr != last->next);

        cout << "Node with key " << key << " not found." << endl;
    }

    void deleteNode(int val) {
        if (last == nullptr) {
            cout << "List is empty. Cannot delete." << endl;
            return;
        }

        CllNode* curr = last->next;
        CllNode* prev = last;

        do {
            if (curr->data == val) {
                if (curr == last && curr->next == last) {
                    last = nullptr;
                } else {
                    prev->next = curr->next;
                    if (curr == last) {
                        last = prev;
                    }
                }
                delete curr;
                cout << "Node with value " << val << " deleted." << endl;
                return;
            }
            prev = curr;
            curr = curr->next;
        } while (curr != last->next);

        cout << "Node with value " << val << " not found." << endl;
    }

    void searchNode(int val) {
        if (last == nullptr) {
            cout << "List is empty." << endl;
            return;
        }

        CllNode* temp = last->next;
        int pos = 1;
        do {
            if (temp->data == val) {
                cout << "Node with value " << val << " found at position " << pos << "." << endl;
                return;
            }
            temp = temp->next;
            pos++;
        } while (temp != last->next);

        cout << "Node with value " << val << " not found." << endl;
    }

    void display() {
        if (last == nullptr) {
            cout << "List is empty." << endl;
            return;
        }

        CllNode* temp = last->next;
        cout << "List (circular): ... -> ";
        do {
            cout << temp->data << " -> ";
            temp = temp->next;
        } while (temp != last->next);
        cout << "... (back to " << last->next->data << ")" << endl;
    }
};

void doublyListMenu() {
    DoublyLinkedList dll;
    int choice, val, key;

    while (true) {
        cout << "\n--- Doubly Linked List Menu ---" << endl;
        cout << "1. Insert at Beginning" << endl;
        cout << "2. Insert at End" << endl;
        cout << "3. Insert After a Node" << endl;
        cout << "4. Insert Before a Node" << endl;
        cout << "5. Delete a Specific Node" << endl;
        cout << "6. Search for a Node" << endl;
        cout << "7. Display List" << endl;
        cout << "8. Return to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value: ";
                cin >> val;
                dll.insertAtBeginning(val);
                break;
            case 2:
                cout << "Enter value: ";
                cin >> val;
                dll.insertAtEnd(val);
                break;
            case 3:
                cout << "Enter key (node data to insert after): ";
                cin >> key;
                cout << "Enter new value: ";
                cin >> val;
                dll.insertAfterNode(key, val);
                break;
            case 4:
                cout << "Enter key (node data to insert before): ";
                cin >> key;
                cout << "Enter new value: ";
                cin >> val;
                dll.insertBeforeNode(key, val);
                break;
            case 5:
                cout << "Enter value to delete: ";
                cin >> val;
                dll.deleteNode(val);
                break;
            case 6:
                cout << "Enter value to search: ";
                cin >> val;
                dll.searchNode(val);
                break;
            case 7:
                dll.display();
                break;
            case 8:
                return;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
}

void circularListMenu() {
    CircularLinkedList cll;
    int choice, val, key;

    while (true) {
        cout << "\n--- Circular Linked List Menu ---" << endl;
        cout << "1. Insert at Beginning" << endl;
        cout << "2. Insert at End" << endl;
        cout << "3. Insert After a Node" << endl;
        cout << "4. Insert Before a Node" << endl;
        cout << "5. Delete a Specific Node" << endl;
        cout << "6. Search for a Node" << endl;
        cout << "7. Display List" << endl;
        cout << "8. Return to Main Menu" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value: ";
                cin >> val;
                cll.insertAtBeginning(val);
                break;
            case 2:
                cout << "Enter value: ";
                cin >> val;
                cll.insertAtEnd(val);
                break;
            case 3:
                cout << "Enter key (node data to insert after): ";
                cin >> key;
                cout << "Enter new value: ";
                cin >> val;
                cll.insertAfterNode(key, val);
                break;
            case 4:
                cout << "Enter key (node data to insert before): ";
                cin >> key;
                cout << "Enter new value: ";
                cin >> val;
                cll.insertBeforeNode(key, val);
                break;
            case 5:
                cout << "Enter value to delete: ";
                cin >> val;
                cll.deleteNode(val);
                break;
            case 6:
                cout << "Enter value to search: ";
                cin >> val;
                cll.searchNode(val);
                break;
            case 7:
                cll.display();
                break;
            case 8:
                return;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
}

int main() {
    int choice;

    while (true) {
        cout << "\n========= Main Menu =========" << endl;
        cout << "1. Doubly Linked List Operations" << endl;
        cout << "2. Circular Linked List Operations" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                doublyListMenu();
                break;
            case 2:
                circularListMenu();
                break;
            case 3:
                cout << "Exiting program." << endl;
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
}