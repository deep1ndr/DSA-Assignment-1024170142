#include <iostream>

using namespace std;

struct DllNode {
    char data;
    DllNode* prev;
    DllNode* next;

    DllNode(char val) {
        data = val;
        prev = nullptr;
        next = nullptr;
    }
};

class DoublyLinkedList {
private:
    DllNode* head;
    DllNode* tail;

public:
    DoublyLinkedList() {
        head = nullptr;
        tail = nullptr;
    }

    ~DoublyLinkedList() {
        DllNode* current = head;
        while (current != nullptr) {
            DllNode* next = current->next;
            delete current;
            current = next;
        }
    }

    void insertAtEnd(char val) {
        DllNode* newNode = new DllNode(val);
        if (tail == nullptr) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    bool isPalindrome() {
        if (head == nullptr) {
            return true;
        }

        DllNode* left = head;
        DllNode* right = tail;

        while (left != right && left->prev != right) {
            if (left->data != right->data) {
                return false;
            }
            left = left->next;
            right = right->prev;
        }

        return true;
    }

    void display() {
        if (head == nullptr) {
            cout << "List is empty." << endl;
            return;
        }
        DllNode* temp = head;
        cout << "List: ";
        while (temp != nullptr) {
            cout << temp->data;
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    DoublyLinkedList dll1;
    dll1.insertAtEnd('r');
    dll1.insertAtEnd('a');
    dll1.insertAtEnd('c');
    dll1.insertAtEnd('e');
    dll1.insertAtEnd('c');
    dll1.insertAtEnd('a');
    dll1.insertAtEnd('r');

    dll1.display();
    if (dll1.isPalindrome()) {
        cout << "The list is a palindrome." << endl;
    } else {
        cout << "The list is not a palindrome." << endl;
    }

    cout << "\n";

    DoublyLinkedList dll2;
    dll2.insertAtEnd('h');
    dll2.insertAtEnd('e');
    dll2.insertAtEnd('l');
    dll2.insertAtEnd('l');
    dll2.insertAtEnd('o');

    dll2.display();
    if (dll2.isPalindrome()) {
        cout << "The list is a palindrome." << endl;
    } else {
        cout << "The list is not a palindrome." << endl;
    }

    cout << "\n";

    DoublyLinkedList dll3;
    dll3.insertAtEnd('m');
    dll3.insertAtEnd('a');
    dll3.insertAtEnd('d');
    dll3.insertAtEnd('a');
    dll3.insertAtEnd('m');

    dll3.display();
    if (dll3.isPalindrome()) {
        cout << "The list is a palindrome." << endl;
    } else {
        cout << "The list is not a palindrome." << endl;
    }

    return 0;
}